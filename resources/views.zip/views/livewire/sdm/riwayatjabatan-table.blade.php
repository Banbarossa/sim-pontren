<div class="table-responsive">
    <table class="table">
        <thead>
            <tr>
                <th>Jabatan</th>
                <th>TMT</th>
                <th>TST</th>
                <th>No SK</th>
                <th>Tanggal SK</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Jabatan</td>
                <td>TMT</td>
                <td>TST</td>
                <td>No SK</td>
                <td>Tanggal SK</td>
            </tr>
        </tbody>
    </table>
    
</div>
