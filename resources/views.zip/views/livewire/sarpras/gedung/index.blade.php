<div class="table-responsive">
    <table class="table table-stripped">
        <thead>
            <tr>
                <th>Nama</th>
                <th>Jumlah Lantai</th>
                <th>Kepemilikan</th>
                <th>Kerusakan</th>
                <th>Tahun Dibangun</th>
                <th>Luas Gedunng</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
        </tbody>
    </table>
</div>
