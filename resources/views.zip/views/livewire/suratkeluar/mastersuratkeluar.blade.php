<div>
    <section class="table-components">
        <div class="container-fluid mt-4">
            <div class="row">
                
                <div class="col-lg-12">
                    <livewire:suratkeluar.suratkeluar-index/>
                    {{-- <div class="card-style mb-3">
                    </div> --}}
                </div>
            </div>
        </div>
    </section>
</div>