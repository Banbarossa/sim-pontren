<div class="col-lg-12">
    <div class="card py-2 px-4 shadow-lg">
        <div class="d-flex align-items-center justify-content-between">
            <h3 class="text-muted py-2">{{ $title }}</h3>
            {{ $slot }}
        </div>
    </div>
</div>