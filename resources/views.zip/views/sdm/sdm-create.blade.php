@extends('layouts.template')
@section('content')



    <section class="table-components">
        <div class="container-fluid mt-4">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-style mb-4">
                        <h3 class="mb-4 border-bottom">Record Rapat</h3>
                        <livewire:sdm.sdm-add>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>




@endsection